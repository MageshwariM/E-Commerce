
package com.niit.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.model.BillingAddress;
//import com.dao.*;
import com.model.UserDetail;
import com.service.UserService;


@Controller
public class LoginController {

	 @Autowired
	    private UserService userService;
	   
	 @RequestMapping("signin")
	    public String login(@RequestParam(value="error", required = false) String error, @RequestParam(value="logout",
	            required = false) String logout, Model model) {
	        if (error!=null) {
	            model.addAttribute("error", "Invalid username and password");
	        }

	        if(logout!=null) {
	            model.addAttribute("msg", "You have been logged out successfully.");
	        }

	        return "signin";
	    }

		@RequestMapping("adminhome")
	public ModelAndView onLoadAdminHome()
	{
		ModelAndView mv=new ModelAndView("adminhome");
	
		return mv;
	}
	/*@RequestMapping("signin")
	public ModelAndView onLoadSignin()
	{
		ModelAndView mv=new ModelAndView("signin");
	
		return mv;
	}*/
		 @RequestMapping(value = "register", method = RequestMethod.POST)
	    public String registerUserPost(@Valid @ModelAttribute("userDetail") UserDetail userDetail, BindingResult result,
	                                       Model model) {
			 String message;

	        if (result.hasErrors()) {
	        	
	            return "signin";
	        }

	        List<UserDetail> userDetailList=userService.getAllUsers();

	        for (int i=0; i< userDetailList.size(); i++) {
	            if(userDetail.getUserEmail().equals(userDetailList.get(i).getUserEmail())) {
	                model.addAttribute("emailMsg", "Email already exists");

	                return "home";
	            }

	            if(userDetail.getUsername().equals(userDetailList.get(i).getUsername())) {
	                model.addAttribute("usernameMsg", "Username already exists");

	                return "home";
	            }
	        }

	        userDetail.setEnabled(true);
	        userService.addUser(userDetail);
	        message="Registered succesfully";
	        model.addAttribute("message",message);
	        return "signin";

	    }
		 @RequestMapping("/register")
		    public String registerUser(Model model) {

		    	UserDetail usersDetail = new UserDetail();
		        BillingAddress billingAddress = new BillingAddress();
		       
		        usersDetail.setBillingAddress(billingAddress);
		       

		        model.addAttribute("usersDetail", usersDetail);
		        model.addAttribute("clickedRegister","true");
		        return "home";

		    }


}
