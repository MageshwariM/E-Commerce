package com.niit.controller;


	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Controller;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.model.Cart;
import com.model.UserDetail;
import com.model.UserOrder;
import com.service.CartService;
import com.service.OrderService;


	/*
	 * This controller is used to handle user order
	 */
	@Controller
	public class OrderController {

		 @Autowired
		    private CartService cartService;

		    @Autowired
		    private OrderService orderService;
		    /*
		     * createOrder method is used to insert user order into the database.
		     */
		    @RequestMapping("/order/{cartId}")
		    public String createOrder(@PathVariable("cartId") int cartId) {
		    	UserOrder userOrder = new UserOrder();
		        Cart cart=cartService.getCartById(cartId);
		        userOrder.setCart(cart);

		        UserDetail usersDetail = cart.getUsersDetail();
		        userOrder.setUsersDetail(usersDetail);
		        //userOrder.setShippingAddress(shippingAddress);

		        orderService.addOrder(userOrder);

		        return "redirect:/checkout?cartId="+cartId;
		    }
		    }


