package com.niit.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.web.bind.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;

import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dao.UserDAO;
import com.model.*;
import com.service.CartService;

/*
 * This controller is called when user clicks on cart menu or button
 */
@Controller
@RequestMapping("user/cart")
public class UserCartController {

    @Autowired
    private UserDAO userDetail;
       /*
     * Initially getCart method is called to get user card items from database
     */
    @RequestMapping
    public String getCartItems(@AuthenticationPrincipal User activeUser){
    	UserDetail userDetails = userDetail.getUserByUsername(activeUser.getUsername());
        int cartId = userDetails.getCart().getCartId();

        return "redirect:/user/cart/"+cartId;
    }
    /*
     * getCartRedirect method is called from getCart method to set retrieved cart from the database.
     */
    @RequestMapping("/{cartId}")
    public String getNewUrl(@PathVariable (value = "cartId") int cartId, Model model) {
 
        model.addAttribute("cartId", cartId);

        return "Cart";
    }

}
