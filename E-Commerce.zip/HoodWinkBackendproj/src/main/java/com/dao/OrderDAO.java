package com.dao;

import com.model.UserOrder;

public interface OrderDAO {
	void addOrder(UserOrder userOrder);

}
