package com.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.model.UserOrder;



@Repository
@Transactional
public class OrderDAOImpl implements OrderDAO{

        @Autowired
        private SessionFactory sessionFactory;

        public OrderDAOImpl(SessionFactory sessionFactory) {
			this.sessionFactory=sessionFactory;
		}

		public void addOrder(UserOrder userOrder) {
            Session session = sessionFactory.getCurrentSession();
            session.saveOrUpdate(userOrder);
            session.flush();
        }
}

