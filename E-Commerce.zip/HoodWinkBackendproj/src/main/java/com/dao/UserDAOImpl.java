package com.dao;

import java.util.List;

//import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;
//import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.annotation.Transactional;

import com.model.Cart;
import com.model.UserDetail;
import com.model.UserRole;
import com.model.Users;

@Repository("userDAO")
@Transactional
public class UserDAOImpl implements UserDAO {
	 @Autowired
	    private SessionFactory sessionFactory;

	    public UserDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory=sessionFactory;
	}

		public void addUser(UserDetail userDetail) {
	        Session session = sessionFactory.getCurrentSession();

	        userDetail.getBillingAddress().setUsersDetail(userDetail);
	        

	        session.saveOrUpdate(userDetail);
	        
	        session.saveOrUpdate(userDetail.getBillingAddress());
	        //session.saveOrUpdate(usersDetail.getShippingAddress());

	        Users newUser = new Users();
	        newUser.setUsername(userDetail.getUsername());
	        newUser.setPassword(userDetail.getPassword());
	        newUser.setEnabled(true);
	        newUser.setUserId(userDetail.getUserId());

	        UserRole newUserRole = new UserRole();
	        newUserRole.setUsername(userDetail.getUsername());
	        newUserRole.setRole("ROLE_USER");
	        session.saveOrUpdate(newUser);
	        session.saveOrUpdate(newUserRole);


	       
	        Cart newCart = new Cart();
	        newCart.setUsersDetail(userDetail);
	        userDetail.setCart(newCart);
	        session.saveOrUpdate(userDetail);
	        session.saveOrUpdate(newCart);

	        session.flush();
	    }

	    public UserDetail getUserById (int userId) {
	        Session session = sessionFactory.getCurrentSession();
	        return (UserDetail) session.get(UserDetail.class, userId);
	    }

	    public List<UserDetail> getAllUsers() {
	        Session session = sessionFactory.getCurrentSession();
	        Query query = session.createQuery("from UserDetail");
	        @SuppressWarnings("unchecked")
			List<UserDetail> userDetail = query.list();

	        return userDetail;
	    }

	    public UserDetail getUserByUsername (String username) {
	        Session session = sessionFactory.getCurrentSession();
	        Query query = session.createQuery("from UserDetail where username = ?");
	        query.setString(0, username);

	        return (UserDetail) query.uniqueResult();
	    }

	/*@Autowired
	private SessionFactory sessionFactory;

	public UserDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public List<UserDetail> list() {
		@SuppressWarnings("unchecked")
		List<UserDetail> list = (List<UserDetail>) sessionFactory.getCurrentSession().createCriteria(UserDetail.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

		return list;
	}

	@Transactional
	public void saveOrUpdate(UserDetail user) {
		System.out.println("dao impl");
		sessionFactory.getCurrentSession().saveOrUpdate(user);
		user.setRole("ROLE_USER");
		user.setEnabled(true);
		 Cart newCart = new Cart();
	        newCart.setUsersDetail(user);
	       // user.setCart(newCart);
	        sessionFactory.getCurrentSession().saveOrUpdate(user);
	        sessionFactory.getCurrentSession().saveOrUpdate(newCart);

	        sessionFactory.getCurrentSession().flush();
	}

	/*
	 * @Transactional public void saveOrUpdate(User userDetails) {
	 * sessionFactory.getCurrentSession().saveOrUpdate(userDetails); }
	 

	@Transactional
	public void delete(String username) {
		UserDetail user = new UserDetail();
		user.setUsername(username);
		sessionFactory.getCurrentSession().delete(user);
	}

	@Transactional
	public UserDetail get(String username) {
		String hql = "from User where username=" + username;
		Query query = sessionFactory.getCurrentSession().createQuery(hql);

		@SuppressWarnings("unchecked")
		List<UserDetail> list = (List<UserDetail>) query.list();

		if (list != null && !list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}

	@Transactional
	public boolean isValidUser(String username, String password) {
		System.out.println("dao impl");
		String hql = "from User where username= '" + username + "' and " + " password ='" + password + "'";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);

		@SuppressWarnings("unchecked")
		List<UserDetail> list = (List<UserDetail>) query.list();

		if (list != null && !list.isEmpty()) {
			return true;
		}

		return false;
	}
*/
}
