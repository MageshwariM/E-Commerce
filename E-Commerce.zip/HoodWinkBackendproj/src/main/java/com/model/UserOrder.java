package com.model;



import javax.persistence.*;
import java.io.Serializable;



@Entity
public class UserOrder implements Serializable{

    private static final long serialVersionUID = 16L;

    @Id
    @GeneratedValue
    private int userOrderId;
	@OneToOne
    @JoinColumn(name = "cartId")
    private Cart cart;
	private long contactnumber;

    public UserDetail getUsersDetail() {
		return usersDetail;
	}

	public void setUsersDetail(UserDetail usersDetail) {
		this.usersDetail = usersDetail;
	}

	public long getContactnumber() {
		return contactnumber;
	}

	public void setContactnumber(long contactnumber) {
		this.contactnumber = contactnumber;
	}

	@OneToOne
    @JoinColumn(name = "username")
    private UserDetail usersDetail;

	   


    private String shippingAddress;

    public int getUserOrderId() {
		return userOrderId;
	}

	public void setUserOrderId(int userOrderId) {
		this.userOrderId = userOrderId;
	}

    public Cart getCart() {
        return cart;
    }

    public void setCart(Cart cart) {
        this.cart = cart;
    }


   

    public String getShippingAddress() {
        return shippingAddress;
    }

    public void setShippingAddress(String shippingAddress) {
        this.shippingAddress = shippingAddress;
    }
   }

