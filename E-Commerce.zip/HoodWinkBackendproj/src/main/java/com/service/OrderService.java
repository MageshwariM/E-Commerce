package com.service;

import com.model.UserOrder;

public interface OrderService {
	 void addOrder(UserOrder order);

	    double getOrderGrandTotal(int cartId);

}
