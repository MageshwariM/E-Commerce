package com.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.ProductDAO;
import com.model.Product;

import java.util.List;



@Service
public class ProductServiceImpl implements ProductService {

  /*  @Autowired
    private ProductDAO itemDao;

    public Product getItemById (int itemId) {
        return itemDao.getItemById(itemId);
    }

    public List<Product> getItemList () {
        return itemDao.getItemList();
    }

    public void addItem(Product item) {
    	itemDao.addItem(item);
    }

    public void editItem(Product item) {
    	itemDao.editItem(item);
    }

    public void deleteItem(Product item) {
    	itemDao.deleteItem(item);
    }*/
}
