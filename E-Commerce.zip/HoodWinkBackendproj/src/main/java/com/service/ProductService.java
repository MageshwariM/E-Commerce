package com.service;

import com.model.Product;

import java.util.List;


public interface ProductService {

	 /* List<Product> getItemList();

	    Product getItemById(int id);

	    void addItem(Product item);

	    void editItem(Product item);

	    void deleteItem(Product item);*/
}
