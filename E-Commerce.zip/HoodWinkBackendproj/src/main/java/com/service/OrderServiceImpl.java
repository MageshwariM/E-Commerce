package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.OrderDAO;
import com.model.Cart;
import com.model.CartItem;
import com.model.UserOrder;

import java.util.List;



@Service
public class OrderServiceImpl implements OrderService{
	 @Autowired
	    private OrderDAO orderDao;

	    @Autowired
	    private CartService cartService;

	    public void addOrder(UserOrder userOrder) {
	    	orderDao.addOrder(userOrder);
	    }

	    public double getOrderGrandTotal(int cartId) {
	        double grandTotal=0;
	        Cart cart = cartService.getCartById(cartId);
	        List<CartItem> cartItems = cart.getCartItems();

	        for (CartItem item : cartItems) {
	            grandTotal+=item.getTotalPrice();
	        }

	        return grandTotal;
	    }
}
