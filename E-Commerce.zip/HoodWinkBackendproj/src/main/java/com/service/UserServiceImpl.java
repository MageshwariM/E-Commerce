package com.service;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.UserDAO;
import com.model.UserDetail;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserDAO userDAO;
	@Autowired
	SessionFactory sessionFactory;

	public UserServiceImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public void addUser(UserDetail usersDetail) {
		userDAO.addUser(usersDetail);
	}

	public UserDetail getUserById(int userId) {
		return userDAO.getUserById(userId);
	}

	public List<UserDetail> getAllUsers() {
		return userDAO.getAllUsers();
	}

	public UserDetail getUserByUsername(String username) {
		return userDAO.getUserByUsername(username);
	}

}
